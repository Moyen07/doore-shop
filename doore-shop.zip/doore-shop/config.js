// ===== Edit only this file to change shop settings =====
window.SHOP = {
  name: "Doore to Doore Shop",
  whatsapp: "8801XXXXXXXXX",   // country code + number, no + or spaces (e.g. 8801712345678). Orders arrive here.
  bkash: "01XXXXXXXXX",        // your bKash personal/merchant number
  nagad: "01XXXXXXXXX",        // your Nagad number
  delivery: 80,                // delivery fee in taka
  freeOver: 3000,              // free delivery above this amount
  sheetWebhook: ""             // optional: Google Apps Script URL (see README) to save orders in Google Sheets
};
