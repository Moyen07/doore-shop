# Doore to Doore Shop

A free, static e-commerce site. No server and no monthly cost.

## Files
- `index.html`, `app.js`, `style.css` – the shop
- `admin.html` – add/edit/delete products
- `products.json` – your product list (the shop reads this)
- `config.js` – WhatsApp, bKash, Nagad numbers, delivery fee
- `logo.svg`, `favicon.svg` – logo
- `images/` – put product photos here

## 1. Put it on GitHub (free hosting)
1. Create a free account at github.com, click **New repository**, name it e.g. `doore-shop`, set it **Public**.
2. Click **uploading an existing file**, drag in ALL files and the `images` folder from this project, click **Commit changes**.
3. Go to **Settings → Pages**. Under *Branch* choose `main` and `/ (root)`, then **Save**.
4. After about a minute your shop is live at `https://YOUR-USERNAME.github.io/doore-shop/`.

## 2. Before you go live
Open `config.js` on GitHub (pencil icon) and replace the `XXXX` numbers with your real WhatsApp, bKash and Nagad numbers. WhatsApp format: `8801712345678`.

## 3. Add or change products
1. Open `https://YOUR-USERNAME.github.io/doore-shop/admin.html`.
2. Add / edit products, click **Download products.json**.
3. On GitHub open your repository, **Add file → Upload files**, upload the new `products.json` (same name replaces the old one). For photos, also upload them into `images/` and write the path like `images/saree.jpg` in the admin form.

The admin page cannot change your live shop by itself. Only your GitHub login can, so strangers cannot damage the site.

## 4. Orders
When a customer orders, WhatsApp opens with the full order text and you receive it. For bKash/Nagad the customer sends money first and gives the Transaction ID; check it in your app before delivering.

### Optional: save orders in Google Sheets
1. Create a Google Sheet, open **Extensions → Apps Script**, paste:
```js
function doPost(e){
  var d=JSON.parse(e.postData.contents);
  SpreadsheetApp.getActiveSheet().appendRow([new Date(),d.order,d.name,d.phone,d.address,d.items,d.subtotal,d.delivery,d.total,d.payment,d.trx]);
  return ContentService.createTextOutput("ok");
}
```
2. **Deploy → New deployment → Web app**, *Execute as: Me*, *Who has access: Anyone*, copy the URL.
3. Paste that URL into `sheetWebhook` in `config.js`.

## Limits
This is a simple shop for starting small. Payments are confirmed by you manually. When orders grow, move to a real backend (Firebase / Supabase) and a payment gateway (SSLCommerz, bKash merchant API).
